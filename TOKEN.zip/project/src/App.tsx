import React, { useState, useEffect } from 'react';
import { 
  CreditCard, 
  Wallet, 
  History, 
  Trophy, 
  Send, 
  Plus,
  ArrowUpRight,
  ArrowDownLeft,
  Coins,
  Gift,
  TrendingUp,
  Star
} from 'lucide-react';

interface Transaction {
  id: string;
  type: 'send' | 'receive';
  amount: number;
  tokensEarned: number;
  recipient?: string;
  sender?: string;
  description: string;
  timestamp: Date;
}

interface Reward {
  id: string;
  name: string;
  cost: number;
  description: string;
  icon: string;
}

function App() {
  const [balance, setBalance] = useState(2450.75);
  const [tokens, setTokens] = useState(1247);
  const [transactions, setTransactions] = useState<Transaction[]>([
    {
      id: '1',
      type: 'send',
      amount: 89.99,
      tokensEarned: 9,
      recipient: 'Coffee Shop',
      description: 'Morning coffee',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000)
    },
    {
      id: '2',
      type: 'receive',
      amount: 250.00,
      tokensEarned: 25,
      sender: 'Sarah Johnson',
      description: 'Dinner split',
      timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000)
    },
    {
      id: '3',
      type: 'send',
      amount: 45.20,
      tokensEarned: 5,
      recipient: 'Uber',
      description: 'Ride home',
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000)
    }
  ]);
  
  const [activeTab, setActiveTab] = useState<'home' | 'send' | 'history' | 'rewards'>('home');
  const [sendAmount, setSendAmount] = useState('');
  const [sendRecipient, setSendRecipient] = useState('');
  const [sendDescription, setSendDescription] = useState('');

  const rewards: Reward[] = [
    { id: '1', name: 'Coffee Voucher', cost: 50, description: '$5 off your next coffee', icon: '☕' },
    { id: '2', name: 'Movie Ticket', cost: 150, description: 'Free movie ticket', icon: '🎬' },
    { id: '3', name: 'Cashback Bonus', cost: 500, description: '10% cashback on next purchase', icon: '💰' },
    { id: '4', name: 'Premium Upgrade', cost: 1000, description: '3 months premium features', icon: '⭐' }
  ];

  const handleSendMoney = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sendAmount || !sendRecipient) return;

    const amount = parseFloat(sendAmount);
    const tokensEarned = Math.floor(amount / 10); // 1 token per $10 spent

    const newTransaction: Transaction = {
      id: Date.now().toString(),
      type: 'send',
      amount,
      tokensEarned,
      recipient: sendRecipient,
      description: sendDescription || 'Payment',
      timestamp: new Date()
    };

    setTransactions([newTransaction, ...transactions]);
    setBalance(prev => prev - amount);
    setTokens(prev => prev + tokensEarned);
    
    // Reset form
    setSendAmount('');
    setSendRecipient('');
    setSendDescription('');
    setActiveTab('home');
  };

  const redeemReward = (reward: Reward) => {
    if (tokens >= reward.cost) {
      setTokens(prev => prev - reward.cost);
      // In a real app, this would trigger the reward redemption
      alert(`Successfully redeemed ${reward.name}!`);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatTime = (date: Date) => {
    return new Intl.RelativeTimeFormat('en', { numeric: 'auto' }).format(
      Math.floor((date.getTime() - Date.now()) / (1000 * 60 * 60)), 'hour'
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-md mx-auto bg-white shadow-2xl min-h-screen">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-8 text-white relative overflow-hidden">
          <div className="absolute inset-0 bg-black opacity-10"></div>
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold">TokenPay</h1>
                <p className="text-blue-100 text-sm">Earn tokens with every transaction</p>
              </div>
              <div className="bg-white bg-opacity-20 p-3 rounded-full">
                <Wallet className="w-6 h-6" />
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <p className="text-blue-100 text-sm">Available Balance</p>
                <p className="text-3xl font-bold">{formatCurrency(balance)}</p>
              </div>
              
              <div className="flex items-center space-x-4 bg-white bg-opacity-10 rounded-2xl p-4">
                <div className="bg-yellow-400 p-2 rounded-full">
                  <Coins className="w-5 h-5 text-yellow-800" />
                </div>
                <div>
                  <p className="text-blue-100 text-sm">TokenPay Coins</p>
                  <p className="text-xl font-bold">{tokens.toLocaleString()}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1">
          {activeTab === 'home' && (
            <div className="p-6 space-y-6">
              {/* Quick Actions */}
              <div>
                <h2 className="text-lg font-semibold text-gray-800 mb-4">Quick Actions</h2>
                <div className="grid grid-cols-2 gap-4">
                  <button
                    onClick={() => setActiveTab('send')}
                    className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-4 rounded-2xl flex flex-col items-center space-y-2 transition-all duration-200 hover:shadow-lg hover:scale-105"
                  >
                    <Send className="w-6 h-6" />
                    <span className="font-medium">Send Money</span>
                  </button>
                  <button
                    onClick={() => setActiveTab('rewards')}
                    className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white p-4 rounded-2xl flex flex-col items-center space-y-2 transition-all duration-200 hover:shadow-lg hover:scale-105"
                  >
                    <Gift className="w-6 h-6" />
                    <span className="font-medium">Rewards</span>
                  </button>
                </div>
              </div>

              {/* Recent Transactions */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold text-gray-800">Recent Activity</h2>
                  <button
                    onClick={() => setActiveTab('history')}
                    className="text-blue-600 text-sm font-medium hover:text-blue-700"
                  >
                    View All
                  </button>
                </div>
                <div className="space-y-3">
                  {transactions.slice(0, 3).map((transaction) => (
                    <div key={transaction.id} className="bg-gray-50 rounded-2xl p-4 flex items-center space-x-4">
                      <div className={`p-2 rounded-full ${
                        transaction.type === 'send' 
                          ? 'bg-red-100 text-red-600' 
                          : 'bg-green-100 text-green-600'
                      }`}>
                        {transaction.type === 'send' ? 
                          <ArrowUpRight className="w-4 h-4" /> : 
                          <ArrowDownLeft className="w-4 h-4" />
                        }
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-gray-800">
                          {transaction.recipient || transaction.sender}
                        </p>
                        <p className="text-sm text-gray-500">{transaction.description}</p>
                      </div>
                      <div className="text-right">
                        <p className={`font-semibold ${
                          transaction.type === 'send' ? 'text-red-600' : 'text-green-600'
                        }`}>
                          {transaction.type === 'send' ? '-' : '+'}{formatCurrency(transaction.amount)}
                        </p>
                        <p className="text-xs text-yellow-600 flex items-center">
                          <Coins className="w-3 h-3 mr-1" />
                          +{transaction.tokensEarned}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'send' && (
            <div className="p-6">
              <div className="flex items-center mb-6">
                <button
                  onClick={() => setActiveTab('home')}
                  className="mr-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <ArrowDownLeft className="w-5 h-5 rotate-90" />
                </button>
                <h2 className="text-xl font-bold text-gray-800">Send Money</h2>
              </div>

              <form onSubmit={handleSendMoney} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Recipient
                  </label>
                  <input
                    type="text"
                    value={sendRecipient}
                    onChange={(e) => setSendRecipient(e.target.value)}
                    placeholder="Enter name or email"
                    className="w-full px-4 py-3 border border-gray-300 rounded-2xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Amount
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={sendAmount}
                    onChange={(e) => setSendAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full px-4 py-3 border border-gray-300 rounded-2xl focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg font-semibold"
                    required
                  />
                  {sendAmount && (
                    <p className="text-sm text-yellow-600 mt-2 flex items-center">
                      <Coins className="w-4 h-4 mr-1" />
                      You'll earn {Math.floor(parseFloat(sendAmount) / 10)} tokens
                    </p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Description (Optional)
                  </label>
                  <input
                    type="text"
                    value={sendDescription}
                    onChange={(e) => setSendDescription(e.target.value)}
                    placeholder="What's this for?"
                    className="w-full px-4 py-3 border border-gray-300 rounded-2xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-4 rounded-2xl font-semibold text-lg hover:shadow-lg transition-all duration-200 hover:scale-105"
                >
                  Send Money
                </button>
              </form>
            </div>
          )}

          {activeTab === 'history' && (
            <div className="p-6">
              <div className="flex items-center mb-6">
                <button
                  onClick={() => setActiveTab('home')}
                  className="mr-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <ArrowDownLeft className="w-5 h-5 rotate-90" />
                </button>
                <h2 className="text-xl font-bold text-gray-800">Transaction History</h2>
              </div>

              <div className="space-y-4">
                {transactions.map((transaction) => (
                  <div key={transaction.id} className="bg-white border border-gray-200 rounded-2xl p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-center space-x-4">
                      <div className={`p-3 rounded-full ${
                        transaction.type === 'send' 
                          ? 'bg-red-100 text-red-600' 
                          : 'bg-green-100 text-green-600'
                      }`}>
                        {transaction.type === 'send' ? 
                          <ArrowUpRight className="w-5 h-5" /> : 
                          <ArrowDownLeft className="w-5 h-5" />
                        }
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <p className="font-semibold text-gray-800">
                            {transaction.recipient || transaction.sender}
                          </p>
                          <p className={`font-bold text-lg ${
                            transaction.type === 'send' ? 'text-red-600' : 'text-green-600'
                          }`}>
                            {transaction.type === 'send' ? '-' : '+'}{formatCurrency(transaction.amount)}
                          </p>
                        </div>
                        <p className="text-sm text-gray-500 mb-2">{transaction.description}</p>
                        <div className="flex items-center justify-between">
                          <p className="text-xs text-gray-400">
                            {formatTime(transaction.timestamp)}
                          </p>
                          <div className="flex items-center text-yellow-600">
                            <Coins className="w-4 h-4 mr-1" />
                            <span className="text-sm font-medium">+{transaction.tokensEarned} tokens</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'rewards' && (
            <div className="p-6">
              <div className="flex items-center mb-6">
                <button
                  onClick={() => setActiveTab('home')}
                  className="mr-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <ArrowDownLeft className="w-5 h-5 rotate-90" />
                </button>
                <h2 className="text-xl font-bold text-gray-800">Token Rewards</h2>
              </div>

              <div className="bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-2xl p-4 mb-6 text-white">
                <div className="flex items-center space-x-3">
                  <div className="bg-white bg-opacity-20 p-2 rounded-full">
                    <Coins className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-yellow-100 text-sm">Available Tokens</p>
                    <p className="text-2xl font-bold">{tokens.toLocaleString()}</p>
                  </div>
                </div>
              </div>

              <div className="grid gap-4">
                {rewards.map((reward) => (
                  <div key={reward.id} className="bg-white border border-gray-200 rounded-2xl p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-center space-x-4">
                      <div className="text-3xl">{reward.icon}</div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-800">{reward.name}</h3>
                        <p className="text-sm text-gray-500 mb-2">{reward.description}</p>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center text-yellow-600">
                            <Coins className="w-4 h-4 mr-1" />
                            <span className="font-medium">{reward.cost} tokens</span>
                          </div>
                          <button
                            onClick={() => redeemReward(reward)}
                            disabled={tokens < reward.cost}
                            className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                              tokens >= reward.cost
                                ? 'bg-blue-600 text-white hover:bg-blue-700 hover:scale-105'
                                : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                            }`}
                          >
                            {tokens >= reward.cost ? 'Redeem' : 'Not enough tokens'}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Bottom Navigation */}
        <div className="bg-white border-t border-gray-200 px-6 py-4">
          <div className="flex justify-around">
            <button
              onClick={() => setActiveTab('home')}
              className={`flex flex-col items-center space-y-1 p-2 rounded-lg transition-colors ${
                activeTab === 'home' ? 'text-blue-600' : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              <Wallet className="w-5 h-5" />
              <span className="text-xs font-medium">Home</span>
            </button>
            <button
              onClick={() => setActiveTab('send')}
              className={`flex flex-col items-center space-y-1 p-2 rounded-lg transition-colors ${
                activeTab === 'send' ? 'text-blue-600' : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              <Send className="w-5 h-5" />
              <span className="text-xs font-medium">Send</span>
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`flex flex-col items-center space-y-1 p-2 rounded-lg transition-colors ${
                activeTab === 'history' ? 'text-blue-600' : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              <History className="w-5 h-5" />
              <span className="text-xs font-medium">History</span>
            </button>
            <button
              onClick={() => setActiveTab('rewards')}
              className={`flex flex-col items-center space-y-1 p-2 rounded-lg transition-colors ${
                activeTab === 'rewards' ? 'text-blue-600' : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              <Trophy className="w-5 h-5" />
              <span className="text-xs font-medium">Rewards</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;